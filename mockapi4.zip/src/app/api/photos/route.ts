import { NextRequest } from "next/server";
import { createPhoto, listPhotos } from "@/db/queries/photos";
import { applyMockControls, applyParsedMockControls } from "@/lib/api/mock-controls";
import {
  internalError,
  jsonError,
  jsonSuccess,
  validationError,
} from "@/lib/api/response";
import {
  createPhotoSchema,
  photoListQuerySchema,
} from "@/lib/validations/photos";

export async function GET(request: NextRequest) {
  try {
    const params = Object.fromEntries(request.nextUrl.searchParams.entries());
    const parsed = photoListQuerySchema.safeParse(params);
    if (!parsed.success) return validationError(parsed.error);

    const { delay, status, ...query } = parsed.data;
    const forced = await applyParsedMockControls({ delay, status });
    if (forced) return forced;

    const result = await listPhotos(query);
    return jsonSuccess(result.items, { pagination: result.pagination });
  } catch (error) {
    console.error("GET /api/photos failed:", error);
    return internalError();
  }
}

export async function POST(request: NextRequest) {
  try {
    const forced = await applyMockControls(request);
    if (forced) return forced;

    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return jsonError("VALIDATION_ERROR", "Invalid JSON body", 400);
    }

    const parsed = createPhotoSchema.safeParse(body);
    if (!parsed.success) return validationError(parsed.error);

    const photo = await createPhoto(parsed.data);
    return jsonSuccess(photo, { status: 201 });
  } catch (error) {
    console.error("POST /api/photos failed:", error);
    return internalError();
  }
}
